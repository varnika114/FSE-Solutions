import './App.css';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';

function App() {

  const showBook = true;
  const showBlog = true;
  const showCourse = true;

  return (
    <div className="container">

      {showCourse && <CourseDetails />}

      {showBook ? <BookDetails /> : null}

      {showBlog ? <BlogDetails /> : null}

    </div>
  );
}

export default App;