import React from "react";
import ListofPlayers from "./ListofPlayers";
import IndianPlayers from "./IndianPlayers";

function App() {

  const flag = true;   // Change to false for second output

  return (
    <div>
      <h1>Cricket App</h1>

      {
        flag ? <ListofPlayers /> : <IndianPlayers />
      }

    </div>
  );
}

export default App;