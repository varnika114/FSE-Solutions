import React from "react";

function ListofPlayers() {

    const players = [
        { name: "Virat", score: 90 },
        { name: "Rohit", score: 82 },
        { name: "Gill", score: 65 },
        { name: "Rahul", score: 74 },
        { name: "Pant", score: 68 },
        { name: "Hardik", score: 88 },
        { name: "Jadeja", score: 60 },
        { name: "Ashwin", score: 72 },
        { name: "Bumrah", score: 55 },
        { name: "Shami", score: 79 },
        { name: "Siraj", score: 69 }
    ];

    const lowScorePlayers = players.filter(player => player.score < 70);

    return (

        <div>

            <h2>List of Players</h2>

            <ul>
                {
                    players.map((player, index) => (
                        <li key={index}>
                            {player.name} - {player.score}
                        </li>
                    ))
                }
            </ul>

            <h2>Players with score below 70</h2>

            <ul>
                {
                    lowScorePlayers.map((player, index) => (
                        <li key={index}>
                            {player.name} - {player.score}
                        </li>
                    ))
                }
            </ul>

        </div>

    );
}

export default ListofPlayers;