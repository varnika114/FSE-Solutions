import React, { Component } from "react";

class App extends Component {

  constructor() {
    super();

    this.state = {
      count: 0,
      amount: "",
      currency: ""
    };
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
  };

  decrement = () => {
    this.setState({ count: this.state.count - 1 });
  };

  sayHello = () => {
    alert("Hello! Member1");
  };

  incrementAndHello = () => {
    this.increment();
    this.sayHello();
  };

  welcome = (msg) => {
    alert(msg);
  };

  onPress = () => {
    alert("I was clicked");
  };

  handleAmount = (e) => {
    this.setState({ amount: e.target.value });
  };

  handleCurrency = (e) => {
    this.setState({ currency: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();

    const result = this.state.amount * 80;

    alert(
      "Converting to " +
        this.state.currency +
        " Amount is " +
        result
    );
  };

  render() {
    return (
      <div style={{ margin: "20px" }}>

        <h3>{this.state.count}</h3>

        <button onClick={this.incrementAndHello}>
          Increment
        </button>

        <br />
        <br />

        <button onClick={this.decrement}>
          Decrement
        </button>

        <br />
        <br />

        <button onClick={() => this.welcome("welcome")}>
          Say welcome
        </button>

        <br />
        <br />

        <button onClick={this.onPress}>
          Click on me
        </button>

        <br />
        <br />

        <h1 style={{ color: "green" }}>
          Currency Convertor!!!
        </h1>

        <form onSubmit={this.handleSubmit}>

          <label>Amount:</label>

          <input
            type="text"
            value={this.state.amount}
            onChange={this.handleAmount}
          />

          <br />
          <br />

          <label>Currency:</label>

          <input
            type="text"
            value={this.state.currency}
            onChange={this.handleCurrency}
          />

          <br />
          <br />

          <button type="submit">
            Submit
          </button>

        </form>

      </div>
    );
  }
}

export default App;