import './App.css';
import office from './images/office.jpg';

function App() {

  const element = "Office Space";

  const officeList = [
    {
      Name: "DBS",
      Rent: 50000,
      Address: "Chennai",
      Image: office
    },
    {
      Name: "TCS",
      Rent: 65000,
      Address: "Bangalore",
      Image: office
    },
    {
      Name: "Infosys",
      Rent: 45000,
      Address: "Hyderabad",
      Image: office
    }
  ];

  return (
    <div className="App">

      <h1>{element}, at Affordable Range</h1>

      {
        officeList.map((item, index) => {

          let colors = [];

          if (item.Rent <= 60000) {
            colors.push("textRed");
          }
          else {
            colors.push("textGreen");
          }

          return (
            <div key={index}>

              <img
                src={item.Image}
                width="25%"
                height="25%"
                alt="Office Space"
              />

              <h2>Name: {item.Name}</h2>

              <h3 className={colors.join(" ")}>
                Rent: Rs. {item.Rent}
              </h3>

              <h3>Address: {item.Address}</h3>

              <hr />

            </div>
          );
        })
      }

    </div>
  );
}

export default App;
